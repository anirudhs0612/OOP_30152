/**
 * 
 */
/**
 * 
 */
module TASK1_PRACTICAL {
}