package mypackage;

public class ImplicitCastingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int intNumber=100;
		long longNumber;
		longNumber=intNumber;
		System.out.println("Integer value:"+intNumber);
		System.out.println("Long value after implicit casting:"+longNumber);
	}

}
