package mypackage;

public class Primitivedatatypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte b=10;
		short s=100;
		int i=1000;
		long l=10000L;
		float f=10.5f;
		double d=20.99;
		char c='A';
		boolean bool=true;
		System.out.println("byte value:"+b);
		System.out.println("short value:"+s);
		System.out.println("int value:"+i);
		System.out.println("long value:"+l);
		System.out.println("float value:"+f);
		System.out.println("double value:"+d);
		System.out.println("char value:"+c);
		System.out.println("boolean value:"+bool);

	}

}

