package mypackage;

public class ExplicitCastingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double decimalNumber=9.78;
		int wholeNumber;
		wholeNumber=(int)decimalNumber;
		System.out.println("Double value:"+decimalNumber);
		System.out.println("Integer value after casting:"+wholeNumber);
	}

}
