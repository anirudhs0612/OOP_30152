package mypackage;

public class Wrapper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=20;
		 Integer i=Integer.valueOf(a);
		   Integer j=a; 
		   System.out.println(a+" "+i+" "+j);  
	}

}
