/**
 * 
 */
/**
 * 
 */
module TASK1_SKILL {
}